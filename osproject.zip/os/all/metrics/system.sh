#!/bin/bash

DATE=$(date '+%Y-%m-%d %H:%M:%S')
TS=$(date +%s)
HOST=$(hostname)

REPORT_DIR="../reports"
MD_OUT="$REPORT_DIR/system.md"
HTML_OUT="$REPORT_DIR/system.html"

mkdir -p "$REPORT_DIR"

# Load averages
read LOAD_1 LOAD_5 LOAD_15 _ < /proc/loadavg

# Number of processes
RUNNING_PROCS=$(ps -e --no-headers | wc -l)

# Uptime (human readable, keep as string)
UPTIME=$(uptime -p)

# CPU usage (locale-safe)
CPU_USAGE=$(LC_ALL=C top -bn1 | awk '/Cpu\(s\)/ {print int($2 + $4)}')

cat <<EOF > "$MD_OUT"
- **Host:** $HOST
- **Date & Time:** $DATE
- **Uptime:** $UPTIME
- **1 minute:** $LOAD_1
- **5 minutes:** $LOAD_5
- **15 minutes:** $LOAD_15
- **Running Processes:** $RUNNING_PROCS
- **CPU Usage:** $CPU_USAGE%
EOF

pandoc "$MD_OUT" -o "$HTML_OUT"

rm $MD_OUT

# ONE JSON object to stdout
jq -n \
  --arg host "$HOST" \
  --arg date "$DATE" \
  --arg uptime "$UPTIME" \
  --argjson load1 "$LOAD_1" \
  --argjson load5 "$LOAD_5" \
  --argjson load15 "$LOAD_15" \
  --argjson procs "$RUNNING_PROCS" \
  --argjson cpu "$CPU_USAGE" \
  --argjson ts "$TS" \
  '{
    metric: "system",
    host: $host,
    datetime: $date,
    load_avg_1m: $load1,
    load_avg_5m: $load5,
    load_avg_15m: $load15,
    running_processes: $procs,
    cpu_usage_percent: $cpu,
    uptime: $uptime,
    timestamp: $ts
  }'
