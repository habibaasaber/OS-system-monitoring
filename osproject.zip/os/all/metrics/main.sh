#!/usr/bin/env bash

./alerts.sh
./cpu.sh
./disk.sh
./memory.sh
./network.sh
./system.sh

