#!/bin/bash

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" >> /tmp/cpu.log
}

HOST=$(hostname)
TS=$(date +%s)

# Store directory
REPORT_DIR="../reports"
MD_OUT="$REPORT_DIR/cpu.md" # Output the MD report 
HTML_OUT="$REPORT_DIR/cpu.html" # Output the HTML report


# Create the directory in case it does not exist
mkdir -p "$REPORT_DIR"

# UNIMPORTANT
model=$(grep "model name" /proc/cpuinfo | head -1 | cut -d':' -f2 | sed 's/^ *//')
cores=$(grep -c "processor" /proc/cpuinfo)

# Locale-safe CPU usage
cpu_idle=$(LC_ALL=C top -bn1 | awk -F',' '/Cpu\(s\)/ {for (i=1;i<=NF;i++) if ($i ~ / id/) {print $i}}' | awk '{print $1}')
cpu_idle=${cpu_idle%.*}
usage=$((100 - cpu_idle))

load=$(awk '{print $1}' /proc/loadavg)
freq=$(powershell.exe "(Get-CimInstance Win32_Processor).CurrentClockSpeed")
# or uptime for 3

log "CPU: Model=$model, Cores=$cores, Usage=${usage}%, Load=$load"

# The markdown report of CPU
cat <<EOF > "$MD_OUT"
- **Model:** $model
- **Cores:** $cores
- **Usage:** $usage%
- **Clock Speed:** $freq Hz
- **Load Avg (1 min):** $load
- **Timestamp:** $(date)
EOF

# Convert markdown into HTML report
pandoc "$MD_OUT" -o "$HTML_OUT"

rm $MD_OUT
# Output ONE JSON message (Kafka expects one message per line)
jq -n \
  --argjson cores "$cores" \
  --argjson usage "$usage" \
  --argjson load "$load" \
  --argjson ts "$TS" \
  '{
    metric: "cpu",
    cores: $cores,
    usage_percent: $usage,
    load_avg_1min: $load,
    timestamp: $ts
  }'
