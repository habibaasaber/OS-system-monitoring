#!/bin/bash
log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" >> /tmp/disk.log
}

disk_line=$(df -h / | tail -1 | tr -s ' ')

total=$(echo "$disk_line" | cut -d' ' -f2)
used=$(echo "$disk_line" | cut -d' ' -f3)
avail=$(echo "$disk_line" | cut -d' ' -f4)
use_pct=$(echo "$disk_line" | cut -d' ' -f5 | tr -d '%')
smart_sts=$(powershell.exe -Command "Get-PhysicalDisk | Select-Object -ExpandProperty OperationalStatus" 2>/dev/null | tr -d '\r')
log "Disk: Total=$total, Used=$used, Avail=$avail, Use%=$use_pct"
echo "Disk Report (/)"
echo "Total: $total"
echo "Used:  $used"
echo "Avail: $avail"
echo "Usage: $use_pct%"
echo "SMART Status: $smart_sts"
echo "Log: /tmp/disk.log"


TS=$(date +%s)

REPORT_DIR="../reports"
MD_OUT="$REPORT_DIR/disk.md"
HTML_OUT="$REPORT_DIR/disk.html"

mkdir -p "$REPORT_DIR"

log "Disk: Total=$total, Used=$used, Avail=$avail, Use%=$use_pct"

cat <<EOF > "$MD_OUT"
# 💽 Disk Report ( / )
- **Total Size:** $total
- **Used:** $used
- **Available:** $avail
- **Usage:** $use_pct%
- **SMART Status:** $smart_sts
EOF

pandoc "$MD_OUT" -o "$HTML_OUT"

rm $MD_OUT

jq -n \
  --arg total "$total" \
  --arg used "$used" \
  --arg avail "$avail" \
  --argjson usage "$use_pct" \
  --argjson ts "$TS" \
  '{
    metric: "disk",
    total: $total,
    used: $used,
    available: $avail,
    usage_percent: $usage,
    timestamp: $ts
  }'
