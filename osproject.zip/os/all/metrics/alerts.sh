#!/bin/bash

CPU_THRESHOLD=80       # CPU usage %
DISK_THRESHOLD=90      # Disk usage %
TEMP_THRESHOLD=75      # CPU temperature °C

ALERT_LOG="/tmp/system_alerts.log"

REPORT_DIR="../reports"
HTML_OUT="$REPORT_DIR/alerts.html" # Output the HTML report

ALERTS=()

log_alert() {
    local msg="$1"
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    ALERTS+=("$timestamp - $msg")
    echo "$timestamp ALERT: $msg" >> "$ALERT_LOG"
}

CPU_USAGE=$(top -bn1 | awk '/Cpu\(s\)/ {print int($2+$4)}')
if [ "$CPU_USAGE" -ge "$CPU_THRESHOLD" ]; then
    log_alert "High CPU Usage: ${CPU_USAGE}% (threshold: $CPU_THRESHOLD%)"
fi

DISK_USAGE=$(df / | awk 'NR==2 {gsub("%",""); print $5}')
if [ "$DISK_USAGE" -ge "$DISK_THRESHOLD" ]; then
    log_alert "High Disk Usage: ${DISK_USAGE}% (threshold: $DISK_THRESHOLD%)"
fi

if [ -f /sys/class/thermal/thermal_zone0/temp ]; then
    TEMP_C=$(awk '{printf "%d\n",$1/1000}' /sys/class/thermal/thermal_zone0/temp)
    if [ "$TEMP_C" -ge "$TEMP_THRESHOLD" ]; then
        log_alert "High CPU Temperature: ${TEMP_C}°C (threshold: $TEMP_THRESHOLD°C)"
    fi
fi

{
cat <<EOF
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>System Security Report</title>
<style>
body { font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px; }
h1 { color: #333; }
.alert { background: #ffdddd; border-left: 6px solid #f44336; padding: 10px; margin-bottom: 10px; }
.safe { background: #ddffdd; border-left: 6px solid #4CAF50; padding: 10px; }
footer { margin-top: 20px; font-size: 0.9em; color: #666; }
</style>
</head>
<body>
<h1>System Hardware Vulnerability Report</h1>
<p>Generated: $(date)</p>
EOF

if [ "${#ALERTS[@]}" -eq 0 ]; then
    echo '<div class="safe"><strong>Device is Ok</strong></div>'
else
    for alert in "${ALERTS[@]}"; do
        echo "<div class=\"alert\">$alert</div>"
    done
fi

cat <<EOF
<footer>
<p>Thresholds — CPU: ${CPU_THRESHOLD}%, Disk: ${DISK_THRESHOLD}%, Temp: ${TEMP_THRESHOLD}°C</p>
</footer>
</body>
</html>
EOF
} > "$HTML_OUT"
