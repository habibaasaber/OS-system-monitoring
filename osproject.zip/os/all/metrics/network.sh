#!/bin/bash

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" >> /tmp/net.log
}

HOST=$(hostname)
TS=$(date +%s)

# Store directory
REPORT_DIR="../reports"
MD_OUT="$REPORT_DIR/network.md" # Output the MD report 
HTML_OUT="$REPORT_DIR/network.html" # Output the HTML report

# Create the directory in case it does not exist
mkdir -p "$REPORT_DIR"

iface=$(ip addr | grep "state UP" | head -1 | cut -d':' -f2 | tr -d ' ')
ip=$(ip addr show "$iface" 2>/dev/null | grep "inet " | head -1 | awk '{print $2}' | cut -d'/' -f1)

read RX TX < <(
  awk '/:/ && $1 !~ /lo:/ {rx+=$2; tx+=$10} END {print rx, tx}' /proc/net/dev
)

log "Network: Interface=$iface, IP=$ip, RX=$RX, TX=$TX"

# The markdown report of network
cat <<EOF > "$MD_OUT"
- **Interface:** $iface
- **IP Address:** $ip
- **Received (RX):** $RX bytes
- **Transmitted (TX):** $TX bytes
- **Timestamp:** $(date)
EOF

# Convert markdown report into HTML report
pandoc "$MD_OUT" -o "$HTML_OUT"

rm $MD_OUT

# ONE JSON object to stdout
jq -n \
  --arg host "$HOST" \
  --arg iface "$iface" \
  --arg ip "$ip" \
  --argjson rx "$RX" \
  --argjson tx "$TX" \
  --argjson ts "$TS" \
  '{
    metric: "network",
    host: $host,
    interface: $iface,
    ip_address: $ip,
    rx_bytes: $rx,
    tx_bytes: $tx,
    timestamp: $ts
  }'