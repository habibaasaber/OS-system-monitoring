#!/bin/bash

log() {
    echo "$(date '+%Y-%m-%d %H:%M:%S'): $1" >> /tmp/mem.log
}

HOST=$(hostname)
TS=$(date +%s)

REPORT_DIR="../reports"
MD_OUT="$REPORT_DIR/memory.md" # Output the MD report 
HTML_OUT="$REPORT_DIR/memory.html" # Output the HTML report

mkdir -p "$REPORT_DIR"

read total used free shared buff_cache available < <(
  LC_ALL=C free -m | awk '/^Mem:/ {print $2, $3, $4, $5, $6, $7}'
)

usage_pct=$(( used * 100 / total ))

log "Memory: Used=${used}MB Total=${total}MB Usage=${usage_pct}%"

cat <<EOF > "$MD_OUT"
- **Total Memory:** $total MB
- **Used Memory:** $used MB
- **Free Memory:** $free MB
- **Usage:** $usage_pct%
- **Timestamp:** $(date)
EOF

pandoc "$MD_OUT" -o "$HTML_OUT"

rm $MD_OUT

jq -n \
  --arg host "$HOST" \
  --argjson total "$total" \
  --argjson used "$used" \
  --argjson free "$free" \
  --argjson usage "$usage_pct" \
  --argjson ts "$TS" \
  '{
    metric: "memory",
    host: $host,
    total_mb: $total,
    used_mb: $used,
    free_mb: $free,
    usage_percent: $usage,
    timestamp: $ts
  }'
