#!/bin/bash


data="clean_data.csv"
OUTPUT_FILE="temp_data.log"
GRAPH_FILE="temp_graph.png"

> "$OUTPUT_FILE"


# clean data of non numerical values
lines=$(wc -l < datamonitor.csv)
head -n $((lines - 2)) datamonitor.csv > $data

# graph for temp
awk -F',' 'NR>1 {print $2, $8}' "$data" > "$OUTPUT_FILE"

gnuplot <<EOF
set terminal png size 700,500
set output "$GRAPH_FILE"
set title "CPU Temp"
set xlabel "Time"
set xdata time
set timefmt "%H:%M:%S"
set format x "%H:%M"
set ylabel "Celsius"
set grid
plot "$OUTPUT_FILE" using 1:2 with lines title "CPU Temp"
EOF

# graph for gpu util
awk -F',' 'NR>1 {print $2, $11}' "$data" > "gpu_util.log"

gnuplot <<EOF
set terminal png size 800,600
set output "gpu_util_graph.png"
set title "GPU Utilization"
set xlabel "Time"
set xdata time
set timefmt "%H:%M:%S"
set format x "%H:%M"
set ylabel "Util"
set grid
plot "gpu_util.log" using 1:2 with lines title "GPU Util %"
EOF

# graph for GPU temp
awk -F',' 'NR>1 {print $2, $10}' "$data" > "gpu_temp.log"

gnuplot <<EOF
set terminal png size 700,500
set output "gpu_temp.png"
set title "GPU Temp"
set xlabel "Time"
set xdata time
set timefmt "%H:%M:%S"
set format x "%H:%M"
set ylabel "Celsius"
set grid
plot "gpu_temp.log" using 1:2 with lines title "GPU Temp"
EOF

# graph for Core utilization
awk -F',' 'NR>1 {print $2, $3, $4, $5, $6}' "$data" > "core_util.log"

gnuplot <<EOF
set terminal png size 700,500
set output "core_util.png"
set title "Per Core Utilization"
set xlabel "Time"
set xdata time
set timefmt "%H:%M:%S"
set format x "%H:%M"
set ylabel "CPU Utilization(%)"
set grid
plot 'core_util.log' using 1:2 with lines title "Core 0", \
     'core_util.log' using 1:3 with lines title "Core 1", \
     'core_util.log' using 1:4 with lines title "Core 2", \
     'core_util.log' using 1:5 with lines title "Core 3"
EOF

# throttle report
read col1 col2 col3 < <(tail -n 1 "$data" | awk -F',' '{print $13, $14, $15}')


cat <<EOF > reports/throttle.html
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Throttle Status</title>
<style>
  body { font-family: Arial, sans-serif; background: #f9f9f9; padding: 20px; }
  .throttle { margin-bottom: 10px; padding: 10px; background: #fff; border-radius: 5px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
  .label { font-weight: bold; }
</style>
</head>
<body>

<div class="throttle"><span class="label">Throttle reason - Power:</span> $col1</div>
<div class="throttle"><span class="label">Throttle reason - Thermal:</span> $col2</div>
<div class="throttle"><span class="label">Throttle reason - Current:</span> $col3</div>

</body>
</html>
EOF

# Date,Time,"Core 0 T0 Utility [%]","Core 1 T0 Utility [%]","Core 2 T0 Utility [%]","Core 3 T0 Utility [%]","Total CPU Utility [%]","CPU (Tctl/Tdie) [�C]","Drive Remaining Life [%]","GPU Temperature [�C]","GPU D3D Usage [%]","GPU Memory Usage [MB]","Throttle Reason - Power [Yes/No]","Throttle Reason - Thermal [Yes/No]","Throttle Reason - Current [Yes/No]",



# alert for drive remaining life 5

#throttle reason 8 power 9 thermal 10 current