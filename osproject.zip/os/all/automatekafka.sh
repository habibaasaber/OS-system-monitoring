#!/bin/bash

KAFKA_TOPIC="system_metrics"
KAFKA_BROKER="localhost:9092"
METRICS_DIR="./metrics"
LOG_FILE="/tmp/system_monitor.log"

while true; do
  for script in "$METRICS_DIR"/*.sh; do
    [ -x "$script" ] || continue

    message=$("$script" 2>>"$LOG_FILE")

    # Skip empty output
    [ -z "$message" ] && continue

    # Log locally
    echo "$message" >> "$LOG_FILE"

    # Send to Kafka
    echo "$message" | kafka-console-producer \
      --broker-list "$KAFKA_BROKER" \
      --topic "$KAFKA_TOPIC"
  done

  sleep 10
done

